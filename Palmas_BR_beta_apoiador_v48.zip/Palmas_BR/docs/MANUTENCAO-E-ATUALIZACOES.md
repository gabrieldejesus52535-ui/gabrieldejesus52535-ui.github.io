# Manutenção e atualizações seguras — Palmas BR

## O que foi preparado
- Controle de manutenção pelo documento `palmas_config/maintenance` no Firestore.
- Aviso de manutenção exibido aos visitantes quando `enabled` for `true`.
- Botão **Ajustes → Modo de manutenção** para administradores conectados.
- Acesso administrativo na tela de manutenção para desligá-la caso seja ativada por engano.
- A mensagem pode ter até 500 caracteres.

## Publicação obrigatória das regras
Antes de usar o recurso, publique as regras atualizadas de `firebase/firestore.rules` no Console do Firebase → Firestore Database → Regras. As regras permitem que todos leiam somente a configuração do aviso, mas apenas uma conta reconhecida em `palmas_admins` a altere. Não substitua as regras do projeto por regras abertas.

## Teste recomendado
1. Faça backup do ZIP atual.
2. Publique primeiro em um site de teste da Netlify.
3. Confirme que login, mensagens e chamadas continuam funcionando.
4. Publique as regras do Firestore.
5. Entre com a conta de administrador, abra Ajustes e ative a manutenção com uma mensagem de teste.
6. Abra o site em uma janela anônima para conferir a tela de manutenção.
7. Desative a manutenção e confirme que o site volta a abrir.
8. Só então publique os arquivos no site principal.

## Atualizações sem interrupção
Em publicação estática, a Netlify troca os arquivos publicados por uma implantação atômica; visitantes que já carregaram a versão antiga podem continuar com arquivos em cache até recarregar. Para testar antes de publicar, use um deploy de prévia/site de teste e mantenha o ZIP anterior para rollback. Atualizações de estrutura de dados no Firestore precisam de plano de compatibilidade próprio.

## Limitações
A tela de manutenção é um bloqueio de interface, não substitui autorização de segurança no Firestore. As regras existentes continuam sendo responsáveis por proteger mensagens, perfis e demais dados. O código de manutenção precisa ser publicado junto com as regras para funcionar.
