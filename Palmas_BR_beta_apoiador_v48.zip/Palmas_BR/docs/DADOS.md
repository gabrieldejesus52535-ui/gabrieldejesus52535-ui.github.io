# Dados

Tudo é salvo em `localStorage["palmas"]` (JSON), objeto `S`:
`servers[]` (id, name, icon, desc, official, verified, ch[]), `msgs{canal:[{u,x,r,t,e}]}` (`t` = hora em ms, `e` = 1 se editada), `sv`/`ch` (servidor e canal atuais), `home` (1 = tela Início), `ft` (aba de Amigos), `fr{usuário: friend|sent|blocked}`, `name`, `user`, `bio`, `status`, `uf`, `av`, `bn`, `joined`, `acct{u,s,h,beta,code}`, `used[]`, `mic`, `hs`, `on`.

- Canais de mensagem direta ficam no servidor `dm` com `dm:1` e id `dm_<usuário>`.
- Senha: guardada como SHA-256 com sal; códigos de convite como hash (não aparecem no arquivo).
- Imagens de perfil: data URL (png/jpeg/gif/webp), validadas pelos bytes iniciais.
- Limpar o `localStorage` apaga a conta e tudo mais.
