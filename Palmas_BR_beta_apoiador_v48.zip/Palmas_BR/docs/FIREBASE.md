# Conectar ao Firebase (conversar entre celulares)

**Situação encontrada:** o código de chat (Firestore + Authentication) já existe no `index.html`, mas está desligado: `var FIREBASE_CONFIG=null;`. Nenhuma configuração do seu projeto estava no pacote, então nada foi inventado. O app usa as coleções `palmas_users`, `palmas_msgs` e `palmas_friends`, com prefixo próprio para não colidir com o seu jogo de RPG no mesmo projeto.

## O que você precisa fazer (uma vez)
1. **Console Firebase > Configurações do projeto > Seus apps > app Web**: copie o objeto de configuração (apiKey, authDomain, projectId, appId). Ele é público por natureza; a segurança vem das regras. Cole em `var FIREBASE_CONFIG=null;` perto do fim do `index.html`. Use o mesmo projeto do RPG.
2. **Authentication > Método de login**: confirme que **E-mail/senha** está ativo (o RPG pode já usar). Os logins do Palmas BR são `usuario@palmas.app`.
3. **Firestore > Regras**: `firebase/firestore.rules` já vem mesclado com as regras do ranking do RPG (cole tudo e publique). Se você tiver mudado as regras do RPG depois, **não substitua** as regras existentes (isso quebraria o RPG). Abra `firebase/firestore.rules` e copie só os blocos `function palmas()`, `function mail(n)` e os três `match /palmas_.../` para dentro do seu `match /databases/{db}/documents { ... }` atual. Publique.
4. Hospede o `index.html` por **https** (Firebase Hosting, Netlify, GitHub Pages) e, em Authentication > Configurações > **Domínios autorizados**, adicione o domínio.
5. Se o Firestore pedir índice, siga o link do erro no console do navegador (as consultas atuais não deveriam pedir).

## Como testar em dois celulares
1. Abra o link https nos dois. No celular A crie conta (código de convite 1, ex. @ana); no B, outro código (ex. @bia).
2. Em A: Início > Amigos > Adicionar amigo > `bia`. Em B: Amigos > Pendentes > Aceitar.
3. Em qualquer um: toque no balão de mensagem do amigo e escreva. A mensagem aparece "enviando…" e, ao confirmar, a marca some; no outro celular chega em tempo real. A conversa fica em Mensagens diretas e o histórico persiste.
4. Teste também um canal da comunidade oficial (ex. Geral): ambos veem as mensagens.
5. Modo avião em um celular: aparece a faixa "Sem conexão" e a mensagem sai quando a internet volta.

## Segurança das regras
- Só contas `@palmas.app` acessam as coleções `palmas_*`; contas do RPG não entram.
- Cada pessoa só lê DMs das quais participa; mensagens não podem ser editadas; só podem ser apagadas pelo autor (DM) ou por ADM (comunidade, via `palmas_admins`); o autor, o nome e a hora são validados pelo servidor.
- Perfis só são criados/alterados pelo dono do @usuário.

## Limitações conhecidas
- Códigos de convite são conferidos no próprio app (quem ler o código-fonte vê como validar). Convites seguros exigem Cloud Functions.
- Qualquer usuário logado pode postar nos canais públicos; restringir Regras/Anúncios a admin exige um campo de papel.
- DMs não exigem amizade aceita no servidor (só na interface).
- Servidores/canais criados por você, reações, fotos e bloqueios ainda são locais.
- Todo o histórico dos canais públicos é baixado ao entrar; para muitas mensagens falta paginação.

## Chamadas de voz e tela
- Usam as coleções `palmas_callpeers` e `palmas_callsig` (regras já em `firebase/firestore.rules`: **publique de novo** as regras atualizadas).
- A sinalização é apagada ao fim da chamada. Se o navegador fechar de repente, a presença expira em ~90 s.
- **TURN (recomendado):** redes móveis e de empresas às vezes bloqueiam a conexão direta. Crie uma conta grátis em metered.ca (Open Relay) ou similar e preencha no `index.html`: `var TURN_SERVERS=[{urls:"turn:HOST:80",username:"USUARIO",credential:"SENHA"}];`. Essas credenciais ficam visíveis a quem abrir o código, então use as de conta gratuita/limitada.

## Digitando… (palmas_typing)
A faixa "fulano está escrevendo…" usa a coleção `palmas_typing` (regras já em `firebase/firestore.rules`: **publique de novo**). Os documentos são apagados quando a pessoa envia ou para de digitar; se o navegador fechar de repente sobra no máximo 1 documento por pessoa e canal, que o app ignora (só vale o que foi atualizado nos últimos ~6 s).


## Atualização de segurança
As regras agora exigem **convite válido no servidor** e perfil para acessar qualquer dado. Veja `docs/SEGURANCA.md` (passo a passo e checklist) antes de publicar. Se publicar sem criar convites, ninguém novo consegue se cadastrar.
