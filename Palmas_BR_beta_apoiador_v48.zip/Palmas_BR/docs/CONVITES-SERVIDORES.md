# Servidores na nuvem e convites por link

Os servidores criados no app agora são **compartilhados de verdade** pelo Firebase. Antes eles existiam só no aparelho de quem criou.

## O que fazer uma vez
Publique as regras novas: Firebase > Firestore > Regras > cole o arquivo `firebase/firestore.rules` (ou, se você usa só o Palmas, o bloco novo de `firebase/firestore.palmas-only.rules`) > Publicar.
Sem isso os links aparecem com aviso de "publique as regras".

## Como funciona
- Ao gerar o primeiro link, o servidor sobe para a nuvem (nome, descrição, idade e canais) e você vira o dono.
- O link é `https://seu-site/#convite=CODIGO`. Quem abrir vê o servidor, toca em **Entrar** e já entra. Se ainda não tiver conta, o convite fica guardado e abre depois do login.
- Opções do link: expira em 30 min, 1 hora, 1 dia, 7 dias ou nunca; limite de usos; nome personalizado (ex.: `#convite=meu-servidor`); vários links ao mesmo tempo; revogar ou apagar a qualquer momento.
- Também dá para colar o link ou só o código em **Entrar com um convite** (tela do botão +).
- Mensagens, membros e canais do servidor sincronizam entre todos. Mudanças de canais feitas pelo dono chegam aos membros.
- Sair do servidor remove você da lista de membros. Se o dono sair, o servidor é apagado.

## Endereço público do link
No navegador o link usa o endereço do site. No app Android (ou em teste local) ele usa `window.PALMAS_PUBLIC_URL`; se não estiver definido, usa `https://eldoria-6720d.web.app/`. Para mudar, coloque no `index.html`: `<script>window.PALMAS_PUBLIC_URL="https://seu-site/"</script>`.

## Limites desta versão
- Regras de canal (somente leitura, modo lento, sala com senha) valem no app, não no servidor do Firebase.
- Só o dono cria links; só mensagens de texto sincronizam (figurinhas e imagens ainda não).
- Cada servidor carrega as últimas 300 mensagens.
- Servidores antigos convidados pelo formato de link anterior (com código longo) não funcionam mais; gere um link novo.
