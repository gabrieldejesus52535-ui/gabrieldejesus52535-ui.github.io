# Criar a conta de ADM

O ADM é uma conta do app que tem um documento em `palmas_admins`. Como o cadastro exige convite e só ADM gera convite, a primeira conta é criada por fora do app, com o script `scripts/criar-adm.js`. Ele cria o login, o perfil, o documento de ADM e, se você quiser, convites.

## Passo a passo (Cloud Shell, funciona no navegador do celular ou do computador)
1. Entre em https://shell.cloud.google.com com a conta Google dona do projeto Firebase.
2. Rode: `gcloud config set project eldoria-6720d`
3. No menu do terminal, use **Upload** e envie `scripts/criar-adm.js` e `scripts/package.json`.
4. Rode: `npm install`
5. Rode (troque os dados): `node criar-adm.js seuusuario "Seu Nome" "SuaSenhaForte123" --convites 10`
6. No app, toque em **Já tenho conta · Entrar** e entre com o usuário e a senha. Depois vá em **Ajustes > Cargos e administração**.

## Cuidados
- A senha só passa pelo seu terminal; o script não a guarda. Não envie essa senha para ninguém.
- Os convites aparecem uma única vez no terminal: copie e guarde.
- Para criar outros ADMs depois, rode o script de novo com outro usuário.

## Sem terminal (manual)
No Console do Firebase: Authentication > Adicionar usuário (e-mail `usuario@palmas.app` + senha). Depois, no Firestore, crie `palmas_users/usuario` (campos `uid` = UID do login, `user`, `n`, `joined`, `inv` com 64 letras/números) e `palmas_admins/usuario` com `ok: true`. O script faz tudo isso de uma vez e com menos chance de erro.
