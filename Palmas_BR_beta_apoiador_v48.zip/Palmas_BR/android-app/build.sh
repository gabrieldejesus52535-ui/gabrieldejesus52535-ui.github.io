#!/usr/bin/env bash
# Gera o APK do Palmas BR (precisa de Node 18+, Java 17+ e Android SDK). Uso: ./build.sh
set -euo pipefail
cd "$(dirname "$0")"
SRC="${1:-..}"

rm -rf www && mkdir -p www
tar -C "$SRC" --exclude=./android-app --exclude=./.github --exclude=./node_modules --exclude=./firebase --exclude=./functions --exclude=./scripts --exclude=./docs --exclude=./README.md -cf - . | tar -C www -xf -

npm install --no-audit --no-fund
[ -d android ] || npx cap add android
npx cap sync android

PKG=android/app/src/main/java/br/palmas/app
mkdir -p "$PKG"
cp native/*.java "$PKG"/

python3 - <<'PY'
import re
p='android/app/src/main/AndroidManifest.xml'
s=open(p,encoding='utf-8').read()
perms=['FOREGROUND_SERVICE','FOREGROUND_SERVICE_MEDIA_PROJECTION','POST_NOTIFICATIONS','RECORD_AUDIO','MODIFY_AUDIO_SETTINGS','WAKE_LOCK']
for x in perms:
    t='<uses-permission android:name="android.permission.%s" />'%x
    if x not in s: s=s.replace('<application',t+'\n    <application',1)
svc='<service android:name=".ScreenShareService" android:exported="false" android:foregroundServiceType="mediaProjection" />'
if 'ScreenShareService' not in s: s=s.replace('</application>','    '+svc+'\n    </application>',1)
open(p,'w',encoding='utf-8').write(s)
PY

( cd android && ./gradlew assembleDebug )
mkdir -p dist && cp android/app/build/outputs/apk/debug/app-debug.apk dist/Palmas-BR.apk
echo "Pronto: android-app/dist/Palmas-BR.apk"
