# Palmas BR para Android (com compartilhamento de tela)

O Chrome, o Samsung Internet e o Firefox do Android não deixam sites compartilharem a tela.
Este projeto empacota o Palmas num app Android e adiciona a captura de tela nativa
(MediaProjection + serviço em primeiro plano). A permissão é a do próprio Android
("Começar agora").

## Opção 1: gerar o APK pelo GitHub (sem instalar nada)
1. Suba o conteúdo da pasta `Palmas_BR` (ela inclui `android-app` e `.github`) para a raiz de um repositório no GitHub.
2. Aba **Actions** > **Gerar APK do Palmas BR** > **Run workflow**.
3. Quando terminar, baixe o artefato **Palmas-BR-apk** (Palmas-BR.apk) e instale no celular
   (libere "Instalar apps desconhecidos" quando o Android pedir).

## Opção 2: gerar no seu computador
Precisa de Node 18+, Java 17+ e Android SDK (ANDROID_HOME configurado):

    cd android-app && ./build.sh

O APK sai em `android-app/dist/Palmas-BR.apk`.

## Como funciona
- `native/ScreenSharePlugin.java`: pede a permissão de gravação de tela e entrega os quadros ao app.
- `native/ScreenShareService.java`: serviço em primeiro plano (notificação "Você está compartilhando a tela").
- No `index.html`, `nativeScreen()` transforma os quadros num vídeo (canvas.captureStream) que vai
  para a chamada WebRTC como qualquer compartilhamento de tela.

## Limites
- Sem áudio do sistema (só o vídeo da tela). O microfone da chamada continua normal.
- Qualidade: até ~1100 px no lado maior, cerca de 8 quadros por segundo.
- A tela só é enviada enquanto o compartilhamento está ativo; para ele pelo botão Parar ou pela notificação.
- Para atualizar o app depois de mudar o `index.html`, gere o APK de novo.
