package br.palmas.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Ponte JS: start() pede a permissão do Android, frame() devolve o último quadro, stop() encerra. */
@CapacitorPlugin(name = "ScreenShare")
public class ScreenSharePlugin extends Plugin {

    @PluginMethod
    public void start(PluginCall call) {
        if (ScreenShareService.running) { call.resolve(info()); return; }
        MediaProjectionManager m = (MediaProjectionManager) getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(call, m.createScreenCaptureIntent(), "onCapture");
    }

    @ActivityCallback
    private void onCapture(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            call.reject("denied");
            return;
        }
        ScreenShareService.stopped = false;
        ScreenShareService.frame = "";
        ScreenShareService.seq = 0;
        Intent s = new Intent(getContext(), ScreenShareService.class);
        s.putExtra("rc", result.getResultCode());
        s.putExtra("data", result.getData());
        if (Build.VERSION.SDK_INT >= 26) getContext().startForegroundService(s);
        else getContext().startService(s);

        final Handler h = new Handler(Looper.getMainLooper());
        final int[] tries = {0};
        h.post(new Runnable() {
            @Override public void run() {
                if (ScreenShareService.running) { call.resolve(info()); }
                else if (++tries[0] > 40) { call.reject("fail"); }
                else { h.postDelayed(this, 100); }
            }
        });
    }

    @PluginMethod
    public void frame(PluginCall call) {
        Integer since = call.getInt("seq", 0);
        JSObject o = new JSObject();
        o.put("stopped", !ScreenShareService.running);
        int cur = ScreenShareService.seq;
        if (since == null || cur > since) {
            o.put("f", ScreenShareService.frame);
            o.put("seq", cur);
        }
        call.resolve(o);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        Intent s = new Intent(getContext(), ScreenShareService.class);
        s.setAction("stop");
        try { getContext().startService(s); } catch (Exception ignored) {}
        call.resolve();
    }

    private JSObject info() {
        JSObject o = new JSObject();
        o.put("w", ScreenShareService.outW);
        o.put("h", ScreenShareService.outH);
        return o;
    }
}
