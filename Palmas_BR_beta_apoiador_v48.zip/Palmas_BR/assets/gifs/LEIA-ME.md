# GIFs

Coloque aqui GIFs ou WebP animados (de preferência até ~1 MB). Nomes só com letras minúsculas, números, - e _ (ex.: `risada.gif`).

Para aparecer na aba GIF, acrescente em `GIF_IMG` no `index.html`:

    GIF_IMG=[["risada.gif","Risada"],["palmas.webp","Palmas"]]

Use só GIFs seus ou que você tem direito de usar.
