# Figurinhas de imagem

Coloque aqui as imagens (PNG, WebP, GIF ou JPG, de preferência quadradas, até ~100 KB).
Use nomes só com letras minúsculas, números, - e _ (ex.: `show.webp`).

Para aparecer no painel, acrescente o arquivo em `STK_IMG` no `index.html`:

    var STK_IMG=[["carteira.webp","Carteira assinada"],["call.webp","Bora call?"]];

As 5 figurinhas desta pasta são memes enviados pela equipe. Imagens não quadradas devem ser ajustadas para quadrado antes (o painel exibe em quadrado).
Use só imagens suas ou que você tem direito de usar.
