// Envia aviso (push) para quem foi marcado com @ numa mensagem do Palmas BR.
// Requer plano Blaze. Deploy: firebase deploy --only functions
const {onDocumentCreated}=require("firebase-functions/v2/firestore");
const admin=require("firebase-admin");
admin.initializeApp();
exports.palmasMencoes=onDocumentCreated("palmas_msgs/{id}",async(ev)=>{
  const m=ev.data&&ev.data.data();if(!m)return;
  const quem=(m.mn||[]).filter(u=>typeof u==="string"&&u!==m.u).slice(0,5);if(!quem.length)return;
  const snaps=await Promise.all(quem.map(u=>admin.firestore().doc("palmas_users/"+u).get()));
  const tokens=[];snaps.forEach(s=>{if(s.exists)(s.data().fcm||[]).forEach(t=>tokens.push(t))});
  if(!tokens.length)return;
  const fig=/^\[figurinha:/.test(m.x||"");
  await admin.messaging().sendEachForMulticast({tokens:tokens.slice(0,200),data:{title:(m.n||m.u)+" te marcou",body:fig?"enviou uma figurinha":String(m.x||"").slice(0,120),ch:String(m.ch||"")},webpush:{headers:{Urgency:"high",TTL:"3600"}}});
});


// ===== Filtro de palavrões da comunidade oficial: censura no servidor, conta avisos e bane no 4º =====
// Mantenha a lista igual à BADWORDS do index.html. Requer plano Blaze. Deploy: firebase deploy --only functions
const BAD=["puta","puto","putaria","putinha","caralho","karalho","krl","crl","porra","merda","bosta","buceta","boceta","bct","cuzao","cu","foda","foder","fodase","fodido","fodida","fdp","vsf","vtnc","pqp","tnc","pnc","arrombado","arrombada","viado","viadinho","piranha","vagabunda","vagabundo","fuck","fucking","shit","bitch","asshole","dick","pussy","cunt"];
const BAN_AT=4,CANAIS=["rg","an","fc","sr","cg","lm","su"];
const LET={a:"[a4@àáâãä]",e:"[e3éèêë]",i:"[i1!íìîï]",o:"[o0óòôõö]",u:"[uúùûü]",s:"[s5$z]",c:"[cçk]",k:"[kcq]",t:"[t7]"};
const RX=new RegExp("(^|[^a-zA-Z0-9À-ÿ])((?:"+BAD.map(w=>w.split("").map(ch=>(LET[ch]||ch)+"+").join("[._\\-*]*")).join("|")+")s?)(?![a-zA-Z0-9À-ÿ])","gi");
function censura(t){let hit=0;const out=String(t).replace(RX,(a,pre,w)=>{hit++;return pre+w.charAt(0)+"*".repeat(w.length-1)});return{t:out,hit};}
exports.palmasFiltro=onDocumentCreated("palmas_msgs/{id}",async(ev)=>{
  const m=ev.data&&ev.data.data();if(!m||m.pub!==true||!CANAIS.includes(m.ch)||typeof m.x!=="string"||typeof m.u!=="string")return;
  const c=censura(m.x);if(!c.hit)return;
  const db=admin.firestore();
  await ev.data.ref.update({x:c.t,cz:true});
  if((await db.doc("palmas_admins/"+m.u).get()).exists)return; // ADM é censurado, mas não leva aviso
  const w=db.doc("palmas_warns/"+m.u);
  const n=await db.runTransaction(async t=>{const s=await t.get(w);const k=(s.exists?(s.data().n||0):0)+1;t.set(w,{n:k,last:admin.firestore.FieldValue.serverTimestamp()});return k;});
  if(n>=BAN_AT)await db.doc("palmas_bans/"+m.u).set({by:"palmas_bot",t:admin.firestore.FieldValue.serverTimestamp(),why:"palavrões"});
});

// ===== Aviso (push) de toda mensagem nova nos canais da comunidade, com o app fechado =====
// Quem mandou aparece no título: "Fulano em #Geral". Quem escolheu "Somente @menções" ou "Nada" (campo pn) não recebe.
// Quem foi marcado já recebe o aviso de menção (palmasMencoes), então não duplica aqui.
const NOTIF_CANAIS={cg:"Geral",an:"Anúncios",fc:"Financiamento Coletivo",sr:"Sorteio",lm:"Links & Mídia"};
exports.palmasCanais=onDocumentCreated("palmas_msgs/{id}",async(ev)=>{
  const m=ev.data&&ev.data.data();
  if(!m||m.pub!==true||!NOTIF_CANAIS[m.ch]||typeof m.u!=="string"||m.u==="@bot")return;
  const marcados=new Set((m.mn||[]).filter(u=>typeof u==="string"));
  const snap=await admin.firestore().collection("palmas_users").select("fcm","pn").get();
  const tokens=[];
  snap.forEach(d=>{
    if(d.id===m.u||marcados.has(d.id))return;
    const x=d.data();if(x.pn==="mn"||x.pn==="none")return;
    (x.fcm||[]).forEach(t=>{if(typeof t==="string")tokens.push(t)});
  });
  if(!tokens.length)return;
  const fig=/^\[figurinha:/.test(m.x||"");
  const data={title:(m.n||m.u)+" em #"+NOTIF_CANAIS[m.ch],body:fig?"enviou uma figurinha":String(m.x||"").slice(0,120),ch:String(m.ch)};
  for(let i=0;i<tokens.length;i+=500){
    await admin.messaging().sendEachForMulticast({tokens:tokens.slice(i,i+500),data,webpush:{headers:{Urgency:"high",TTL:"3600"}}});
  }
});
